This is a readme for assignment 4. Please unzip the zip file and make.

After making you may run the following command:

      ./locationUpdater 10 < input_posted.txt 


You will see some output. You can try the same command 
with varying number of processes (5 , 7, 20 etc.).


