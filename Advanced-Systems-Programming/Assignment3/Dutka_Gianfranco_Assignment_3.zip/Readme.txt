Please unzip the zipped assignment. 


Use make to build the project. 


After that you should be able to run with th following: 

	./eft 4 < input_posted.txt

