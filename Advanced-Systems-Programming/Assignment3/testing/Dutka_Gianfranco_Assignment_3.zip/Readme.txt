Please unzip the zipped assignment. 


Use make to build the project. 


After that you should be able to run with th following: 

	./eft input_posted.txt 4


There MUST be an input file passed into the program. The number of threads MUST be greater than zero. 
Some more sample input and output would of been helpful when writing this program. There are some edge 
cases like defining the same account twice and how to handle the case if the user inputs a 0 as the 
number of worker threads. 

Since these edge cases were not mentioned on the assignment PDF I wrote the assignment under the 
following assumptions. 

1. There cannot be zero worker threads. 

2. You cannot create the same account twice when creating accounts.

3. There must be two arguments when running this program. 

