To run this program please do the following. 

1. Unzip the zip file
2. run make 
3. ./locationUpdater 10 < input_posted.txt

The output will be present on the console. You can 
change the arguments from 10 to some other number 
like 1 or 2 and it will set the maximum size the
of the dynamic buffer and limit the 
producer/consumer by not allowing them to read/write
when they are not supposed to.