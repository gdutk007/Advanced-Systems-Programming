To create the executable please enter 'make' on the console. 

The executable name should be 'sim'.

To correctly run the binary enter the name of the 'sim' binary and the text file to which it corresponds. 

example :sudo ./sim text.txt

^^^ The above command uses sudo and also taken in a file called 'test.txt'. The test.txt file is included in 
the submission. 


You can enter 'make clean' to remove the binary. 

